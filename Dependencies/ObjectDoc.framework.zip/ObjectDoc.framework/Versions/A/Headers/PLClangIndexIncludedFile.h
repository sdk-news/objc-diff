//
//  PLClangIndexIncludedFileInfo.h
//  ObjectDoc
//
//  Created by lizhuoli on 2019/4/16.
//  Copyright © 2019 Landon Fuller. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface PLClangIndexIncludedFile : NSObject

@end

NS_ASSUME_NONNULL_END
